from django.apps import AppConfig


class AppquanlyConfig(AppConfig):
    name = 'appquanly'
